from ScrawlingHelper import ScrawlingHelper
from RequestUtility import RequestUtility
from enum import Enum
import time

class Tags(Enum):
    ANCHOR = "a"
    PARAGRAPH = "p"
    BODY = "body"
    HEAD = "head"
    TITLE = "title"
    PRODUCT_NAME_CLASS = "name-main wrap-two-lines"

class Attributes(Enum):
    ID = "id"
    HREF = "href"
    CLASS = "class"

product_name = []
product_price = []
product_unit_price = []
product_category_uri = []

if __name__ == '__main__':
    def getProductCategoriesUri():
        webPageResponse = RequestUtility("https://oda.com/")
        beautifiedResponse = ScrawlingHelper.getBeautifulSoupData(webPageResponse.getWebPage())
        return ScrawlingHelper.getAllProductCategoryUri(beautifiedResponse,".product-category__link")


    product_category_uri = getProductCategoriesUri()
    for category in product_category_uri:
        time.sleep(2)
        print("Executing cateory {0}...".format(category))
        webPageResponseAll = RequestUtility("https://oda.com"+category)
        beautifiedResponse = ScrawlingHelper.getBeautifulSoupData(webPageResponseAll.getWebPage())
        product_name.extend(ScrawlingHelper.getProductNameAndPriceScrapped(beautifiedResponse, "name"))
        product_price.extend(ScrawlingHelper.getProductNameAndPriceScrapped(beautifiedResponse, "price"))

    product_and_price_data = list(zip(product_name, product_price))
    for values in product_and_price_data:
        print(values)






