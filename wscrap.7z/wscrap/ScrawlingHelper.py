from bs4 import BeautifulSoup


class ScrawlingHelper:

    def __init__(self):
        pass

    @classmethod
    def getBeautifulSoupData(cls, wdata):
        soup = BeautifulSoup(wdata, 'html.parser')
        return soup

    @classmethod
    def getFindAllByTag(cls, response, selector):
        return response.find_all(selector)

    @classmethod
    def getFindAllByTagClass(cls, response, selector, classname):
        return response.find_all(selector, class_= classname)

    @classmethod
    def selectElementsByClass(cls, response, classname):
        return response.select(classname)

    @classmethod
    def selectElementByClass(cls, response, classname):
        return response.select_one(classname)

    @classmethod
    def getAllProductCategoryUri(cls, response, classname):
        product_category_uri = []
        categorylist = response.select(classname)
        for cat in categorylist:
            product_category_uri.append(cat.get("href"))
        return product_category_uri


    @classmethod
    def getProductNameAndPriceScrapped(cls, beautifiedResponse, query):
        product_name = []
        product_price = []
        product_unit_price = []
        listOfElement = ScrawlingHelper.selectElementsByClass(beautifiedResponse, ".modal-link")
        for element in listOfElement:
            nameelements = ScrawlingHelper.selectElementsByClass(element, ".name")
            priceelements = ScrawlingHelper.selectElementsByClass(element, ".price")
            unitpriceelements = ScrawlingHelper.selectElementsByClass(element, ".unit-price")
            for nameelement in nameelements:
                nameelementclass = ScrawlingHelper.selectElementByClass(nameelement, ".name-main").getText()
                product_name.append(nameelementclass)
            for priceelement in priceelements:
                product_price.append(priceelement.getText())
            for unitpriceelement in unitpriceelements:
                product_unit_price.append(unitpriceelement.getText())

        if (query == "name"):
            return product_name
        elif (query == "price"):
            return product_price
        elif (query == "price"):
            return product_unit_price



