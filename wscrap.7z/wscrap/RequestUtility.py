import urllib.request
from bs4 import BeautifulSoup


class RequestUtility:

    def __init__(self, host):
        self.host = host

    def getWebPage(self):
        response = urllib.request.urlopen(self.host).read()
        return response



