import csv

import OdaConstants
from ScrawlingHelper import ScrawlingHelper
from RequestUtility import RequestUtility
from urllib.error import HTTPError
import time

product_name = []
product_price = []
product_unit_price = []
product_category_uri = []

#main where the program execution starts
if __name__ == '__main__':
    #Looping through the list of product URIs to perform a get request on each of them in order to retrieve the resposnes as desired data.
    product_category_uri = ScrawlingHelper.getProductCategoriesUri()
    for category in product_category_uri:
        time.sleep(2)
        print("Executing cateory {0}...".format(category))
        webPageResponseAll = RequestUtility("https://oda.com"+category)
        try:
            webPageResponseToBeBeautified = webPageResponseAll.getWebPage()
            type(webPageResponseToBeBeautified)
            beautifiedResponse = ScrawlingHelper.getBeautifulSoupData(webPageResponseToBeBeautified)
            product_name.extend(ScrawlingHelper.getProductNameAndPriceScrapped(beautifiedResponse, "name"))
            product_price.extend(ScrawlingHelper.getProductNameAndPriceScrapped(beautifiedResponse, "price"))
        except Exception as e:
            print("###We have found the following error: {0}###".format(e))

    #Performing item name and price data mapping
    product_and_price_data = list(zip(product_name, product_price))
    for values in product_and_price_data:
        print(values)

    #Generating CSV file for the item name and price collection
    with open('product_data.csv', 'w') as out:
        csv_out=csv.writer(out)
        csv_out.writerow(['Product Name', 'Product Price'])
        print("Generating product_data.csv file")
        for row in product_and_price_data:
            csv_out.writerow(row)






