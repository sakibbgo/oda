from enum import Enum

class Tags(Enum):
        ANCHOR = "a"
        PARAGRAPH = "p"
        BODY = "body"
        HEAD = "head"
        TITLE = "title"

class Attributes(Enum):
        ID = "id"
        HREF = "href"
        CLASS = "class"

class OdaPageSelectors(Enum):
        PRODUCT_CATEGORY_LINK_CLASS = ".product-category__link"
        PARENT_FOR_EACH_PRODUCT_CLASS = ".modal-link"
        PRODUCT_NAME_CLASS = ".name"
        PRODUCT_PRICE_CLASS = ".price"
        PRODUCT_UNIT_PRICE_CLASS = ".unit-price"
        PRODUCT_NAME_MAIN_CLASS = ".name-main"