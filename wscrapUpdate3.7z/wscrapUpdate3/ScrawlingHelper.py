from bs4 import BeautifulSoup
import OdaConstants
from RequestUtility import RequestUtility

class ScrawlingHelper:

    def __init__(self):
        pass

    @classmethod
    def getBeautifulSoupData(cls, wdata):
        try:
            soup = BeautifulSoup(wdata, 'html.parser')
            return soup
        except Exception as e:
            print(e)

    # A method to get all the uri of different product categories
    @classmethod
    def getProductCategoriesUri(cls):
        webPageResponse = RequestUtility("https://oda.com/")
        beautifiedResponse = ScrawlingHelper.getBeautifulSoupData(webPageResponse.getWebPage())
        return ScrawlingHelper.getAllProductCategoryUri(beautifiedResponse, OdaConstants.OdaPageSelectors.PRODUCT_CATEGORY_LINK_CLASS.value)

    #Parameterized function that takes in HTML response beautified with BeautifulSoup to perform various operations on them. The second paramter helps identifiying which value should be return among all the available scrapped data.
    @classmethod
    def getProductNameAndPriceScrapped(cls, beautifiedResponse, query):
        try:
            product_name = []
            product_price = []
            product_unit_price = []
            listOfElement = ScrawlingHelper.selectElementsByClass(beautifiedResponse, OdaConstants.OdaPageSelectors.PARENT_FOR_EACH_PRODUCT_CLASS.value)
            for element in listOfElement:
                nameelements = ScrawlingHelper.selectElementsByClass(element, OdaConstants.OdaPageSelectors.PRODUCT_NAME_CLASS.value)
                priceelements = ScrawlingHelper.selectElementsByClass(element, OdaConstants.OdaPageSelectors.PRODUCT_PRICE_CLASS.value)
                unitpriceelements = ScrawlingHelper.selectElementsByClass(element, OdaConstants.OdaPageSelectors.PRODUCT_UNIT_PRICE_CLASS.value)
                for nameelement in nameelements:
                    nameelementclass = ScrawlingHelper.selectElementByClass(nameelement, OdaConstants.OdaPageSelectors.PRODUCT_NAME_MAIN_CLASS.value).getText()
                    product_name.append(nameelementclass.rstrip())
                for priceelement in priceelements:
                    product_price.append(priceelement.getText().rstrip())
                for unitpriceelement in unitpriceelements:
                    product_unit_price.append(unitpriceelement.getText().rstrip())

            if (query == "name"):
                return product_name
            elif (query == "price"):
                return product_price
            elif (query == "price"):
                return product_unit_price
        except Exception as e:
            print(e)

    @classmethod
    def getFindAllByTag(cls, response, selector):
        return response.find_all(selector)

    @classmethod
    def getFindAllByTagClass(cls, response, selector, classname):
        return response.find_all(selector, class_= classname)

    @classmethod
    def selectElementsByClass(cls, response, classname):
        return response.select(classname)

    @classmethod
    def selectElementByClass(cls, response, classname):
        return response.select_one(classname)

    @classmethod
    def getAllProductCategoryUri(cls, response, classname):
        product_category_uri = []
        categorylist = response.select(classname)
        for cat in categorylist:
            product_category_uri.append(cat.get(OdaConstants.Attributes.HREF.value))
        return product_category_uri


