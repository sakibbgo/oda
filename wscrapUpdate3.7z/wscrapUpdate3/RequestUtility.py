import urllib.request
from urllib.error import HTTPError
from bs4 import BeautifulSoup

class RequestUtility:

    def __init__(self, host):
        self.host = host

    def getWebPage(self):
        try:
            with urllib.request.urlopen(self.host) as response:
                return response.read()
        except Exception as e:
            print("###We have found the following error: {0}###".format(e))
            return e




