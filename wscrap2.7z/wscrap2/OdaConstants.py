from enum import Enum


class Tags(Enum):
        ANCHOR = "a"
        PARAGRAPH = "p"
        BODY = "body"
        HEAD = "head"
        TITLE = "title"
        PRODUCT_NAME_CLASS = "name-main wrap-two-lines"

class Attributes(Enum):
        ID = "id"
        HREF = "href"
        CLASS = "class"